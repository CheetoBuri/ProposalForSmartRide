﻿namespace Repository
{
    public class ManagerRepository
    {
    }
}

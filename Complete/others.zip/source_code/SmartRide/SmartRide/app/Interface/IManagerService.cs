﻿namespace Interface
{
    public interface IManagerService
    {
    }
}

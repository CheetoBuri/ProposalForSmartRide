﻿using Models;

namespace Interface
{
    public interface IHomeService
    {
        List<Account> GetAllAccounts();
    }
}

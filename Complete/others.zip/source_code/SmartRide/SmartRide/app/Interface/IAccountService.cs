﻿using Models;

namespace Interface
{
    public interface IAccountService
    {
        List<Account> GetAllAccounts();
    }

}
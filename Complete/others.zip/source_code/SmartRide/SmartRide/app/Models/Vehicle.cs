﻿namespace Models
{
    public class Vehicle
    {
        public Guid VehicleId { get; set; }
        public string Model { get; set; }
        public string LicensePlate { get; set; }
        public string Type { get; set; }
    }

}

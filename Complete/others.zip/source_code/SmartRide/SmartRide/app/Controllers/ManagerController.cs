﻿namespace Controllers
{
    public class ManagerController
    {
    }
}

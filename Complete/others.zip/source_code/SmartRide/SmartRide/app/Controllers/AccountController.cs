﻿//using Services;
//using Models;
//using Repository;

//namespace Controllers
//{
//    public class AccountController
//    {
//        private readonly HomeService _homeService;
//        public AccountController()
//        {
//            _homeService = new HomeService();
//        }
//        public List<Account> GetAllAccounts()
//        {
//            var result = _homeService.GetAllAccounts();
//            if (result != null)
//            {
//                return result;
//            }
//            return null;
//        }
//    }
//}

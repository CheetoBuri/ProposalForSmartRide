﻿namespace Controllers
{
    public class CustomerController
    {
        public CustomerController() { }

        public string addCustomer()
        {
            return "Customer added successfully.";
        }
    }
}

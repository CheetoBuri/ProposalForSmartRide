﻿namespace Controllers
{
    public class VehicleController
    {
    }
}

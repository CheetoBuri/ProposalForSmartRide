﻿namespace Controllers
{
    public class LocationController
    {
    }
}

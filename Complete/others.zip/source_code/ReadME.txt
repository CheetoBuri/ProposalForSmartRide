How to run program:

+ open the SmartRide.sln
+ Acess to console, run command:
docker-compose up --build
+ Run the project
+ The demo include:
- Register
- Login
- Home page
- Book Ride
- Driver page
- Track Ride for Driver
- Track Rider for Customer